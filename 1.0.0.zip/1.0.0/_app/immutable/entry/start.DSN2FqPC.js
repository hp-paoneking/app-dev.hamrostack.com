import{c as a}from"../chunks/entry.BCw_l00_.js";export{a as start};
